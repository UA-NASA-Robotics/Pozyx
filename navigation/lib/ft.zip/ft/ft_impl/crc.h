#ifndef FT_CRC_H
#define FT_CRC_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

uint8_t crc (uint8_t const *, uint8_t);

#ifdef __cplusplus
}
#endif
#endif // FT_CRC_H
